
    let currentCurrency = 'COP';
    const exchangeRates = { COP: 1, USD: 0.00025, USDT: 0.00025 };

    let currentUser = null; // null si no ha iniciado sesión

    let catalogData = [
      { id: "TYR-1001", code: "DEMO-CAT-001", name: "Pastillas de Freno Delanteras Toyota Hilux / Fortuner", brand: "Toyota", priceCOP: 185000, stock: 42, loc: "Pasillo 1 - Estante 2 - Cajón 4", specs: "Ejemplo de catálogo. Referencia y compatibilidad pendientes de confirmación.", img: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzODAgMjcwIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9Im1ldGFsIiB4Mj0iLjkiIHkyPSIxIj48c3RvcCBzdG9wLWNvbG9yPSIjZDVkY2RmIi8+PHN0b3Agb2Zmc2V0PSIuNDUiIHN0b3AtY29sb3I9IiM4OTliYTMiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNjN2QwZDQiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iMzgwIiBoZWlnaHQ9IjI3MCIgZmlsbD0iIzE5MWQyMCIvPjxlbGxpcHNlIGN4PSIxOTAiIGN5PSIyMjUiIHJ4PSIxMDMiIHJ5PSI5IiBmaWxsPSIjMTczMTM5IiBvcGFjaXR5PSIuMDgiLz48cGF0aCBkPSJNMTAwIDEwNXE4MC02MCAxODAgMHY3MHEtMTAwIDIyLTE4MC04WiIgZmlsbD0idXJsKCNtZXRhbCkiLz48cGF0aCBkPSJNMTEzIDEyMHE4NS00MSAxNTQtMnY0MnEtNzMgMTgtMTU0LTdaIiBmaWxsPSIjMjczNjNiIi8+PHBhdGggZD0iTTEzMCAxMzFxNjUtMjQgMTE4IDBNMTMwIDE0NXE2NS0yMCAxMTggMCIgc3Ryb2tlPSIjNmE3YzgzIiBzdHJva2Utd2lkdGg9IjMiLz48L3N2Zz4=" },
      { id: "TYR-1002", code: "DEMO-CAT-002", name: "Kit Distribución Completo Renault Duster / Logan / Sandero 1.6", brand: "Renault", priceCOP: 245000, stock: 28, loc: "Pasillo 1 - Estante 3 - Cajón 1", specs: "Ejemplo de catálogo. Referencia y compatibilidad pendientes de confirmación.", img: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzODAgMjcwIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9Im1ldGFsIiB4Mj0iLjkiIHkyPSIxIj48c3RvcCBzdG9wLWNvbG9yPSIjZDVkY2RmIi8+PHN0b3Agb2Zmc2V0PSIuNDUiIHN0b3AtY29sb3I9IiM4OTliYTMiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNjN2QwZDQiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iMzgwIiBoZWlnaHQ9IjI3MCIgZmlsbD0iIzE5MWQyMCIvPjxlbGxpcHNlIGN4PSIxOTAiIGN5PSIyMjUiIHJ4PSIxMDMiIHJ5PSI5IiBmaWxsPSIjMTczMTM5IiBvcGFjaXR5PSIuMDgiLz48ZWxsaXBzZSBjeD0iMTg1IiBjeT0iMTM3IiByeD0iMTEwIiByeT0iNzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzI4MzgzZSIgc3Ryb2tlLXdpZHRoPSIxOSIvPjxlbGxpcHNlIGN4PSIxODUiIGN5PSIxMzciIHJ4PSIxMDAiIHJ5PSI2MiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjOGI5YmEwIiBzdHJva2Utd2lkdGg9IjQiIHN0cm9rZS1kYXNoYXJyYXk9IjcgNiIvPjxjaXJjbGUgY3g9IjE4NSIgY3k9IjEzNyIgcj0iNDIiIGZpbGw9InVybCgjbWV0YWwpIi8+PGNpcmNsZSBjeD0iMTg1IiBjeT0iMTM3IiByPSIxMyIgZmlsbD0iIzI3MzYzYiIvPjwvc3ZnPg==" },
      { id: "TYR-1003", code: "DEMO-CAT-003", name: "Bomba de Agua Isuzu NKR / NPR / NHR Motor 4HG1", brand: "Isuzu", priceCOP: 320000, stock: 15, loc: "Pasillo 2 - Estante 1 - Cajón 3", specs: "Ejemplo de catálogo. Referencia y compatibilidad pendientes de confirmación.", img: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzODAgMjcwIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9Im1ldGFsIiB4Mj0iLjkiIHkyPSIxIj48c3RvcCBzdG9wLWNvbG9yPSIjZDVkY2RmIi8+PHN0b3Agb2Zmc2V0PSIuNDUiIHN0b3AtY29sb3I9IiM4OTliYTMiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNjN2QwZDQiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iMzgwIiBoZWlnaHQ9IjI3MCIgZmlsbD0iIzE5MWQyMCIvPjxlbGxpcHNlIGN4PSIxOTAiIGN5PSIyMjUiIHJ4PSIxMDMiIHJ5PSI5IiBmaWxsPSIjMTczMTM5IiBvcGFjaXR5PSIuMDgiLz48cGF0aCBkPSJNMTM4IDg3aDkwbDIwIDM1IDQwIDIwLTEwIDQ1aC02NmwtMTgtMjUtNDcgMTMtMjctMzNaIiBmaWxsPSJ1cmwoI21ldGFsKSIgc3Ryb2tlPSIjNTM2NzZlIiBzdHJva2Utd2lkdGg9IjIiLz48Y2lyY2xlIGN4PSIyMDQiIGN5PSIxMzMiIHI9IjM5IiBmaWxsPSIjMjczNjNiIi8+PGNpcmNsZSBjeD0iMjA0IiBjeT0iMTMzIiByPSIyNSIgZmlsbD0idXJsKCNtZXRhbCkiLz48Y2lyY2xlIGN4PSIyMDQiIGN5PSIxMzMiIHI9IjkiIGZpbGw9IiMyNzM2M2IiLz48L3N2Zz4=" },
      { id: "TYR-1004", code: "DEMO-CAT-004", name: "Kit de Embrague Chevrolet Sail 1.4 LUK / Valeo", brand: "Chevrolet", priceCOP: 380000, stock: 19, loc: "Pasillo 3 - Estante 2 - Cajón 2", specs: "Ejemplo de catálogo. Referencia y compatibilidad pendientes de confirmación.", img: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzODAgMjcwIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9Im1ldGFsIiB4Mj0iLjkiIHkyPSIxIj48c3RvcCBzdG9wLWNvbG9yPSIjZDVkY2RmIi8+PHN0b3Agb2Zmc2V0PSIuNDUiIHN0b3AtY29sb3I9IiM4OTliYTMiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNjN2QwZDQiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iMzgwIiBoZWlnaHQ9IjI3MCIgZmlsbD0iIzE5MWQyMCIvPjxlbGxpcHNlIGN4PSIxOTAiIGN5PSIyMjUiIHJ4PSIxMDMiIHJ5PSI5IiBmaWxsPSIjMTczMTM5IiBvcGFjaXR5PSIuMDgiLz48Y2lyY2xlIGN4PSIxODUiIGN5PSIxNDAiIHI9IjgwIiBmaWxsPSJ1cmwoI21ldGFsKSIgc3Ryb2tlPSIjNTM2NzZlIiBzdHJva2Utd2lkdGg9IjMiLz48Y2lyY2xlIGN4PSIxODUiIGN5PSIxNDAiIHI9IjU5IiBmaWxsPSIjMjkzZDQ0Ii8+PGNpcmNsZSBjeD0iMTg1IiBjeT0iMTQwIiByPSI0MCIgZmlsbD0idXJsKCNtZXRhbCkiLz48Y2lyY2xlIGN4PSIxODUiIGN5PSIxNDAiIHI9IjE3IiBmaWxsPSIjMjkzZDQ0Ii8+PHBhdGggZD0ibTE4NSAxMDAgMCA4MG0tNDAtNDBoODBtLTY5LTI5IDU3IDU3bTAtNTctNTcgNTciIHN0cm9rZT0iIzU3NmU3NiIgc3Ryb2tlLXdpZHRoPSI3Ii8+PC9zdmc+" },
      { id: "TYR-1005", code: "DEMO-CAT-005", name: "Disco Freno Delantero Ventilado Nissan Frontier D22 / NP300", brand: "Nissan", priceCOP: 210000, stock: 12, loc: "Pasillo 2 - Estante 3 - Cajón 1", specs: "Ejemplo de catálogo. Referencia y compatibilidad pendientes de confirmación.", img: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzODAgMjcwIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9Im1ldGFsIiB4Mj0iLjkiIHkyPSIxIj48c3RvcCBzdG9wLWNvbG9yPSIjZDVkY2RmIi8+PHN0b3Agb2Zmc2V0PSIuNDUiIHN0b3AtY29sb3I9IiM4OTliYTMiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNjN2QwZDQiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iMzgwIiBoZWlnaHQ9IjI3MCIgZmlsbD0iIzE5MWQyMCIvPjxlbGxpcHNlIGN4PSIxOTAiIGN5PSIyMjUiIHJ4PSIxMDMiIHJ5PSI5IiBmaWxsPSIjMTczMTM5IiBvcGFjaXR5PSIuMDgiLz48Y2lyY2xlIGN4PSIxODUiIGN5PSIxNDAiIHI9Ijg0IiBmaWxsPSJ1cmwoI21ldGFsKSIvPjxjaXJjbGUgY3g9IjE4NSIgY3k9IjE0MCIgcj0iNjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzc3ODg4ZSIvPjxjaXJjbGUgY3g9IjE4NSIgY3k9IjE0MCIgcj0iNDAiIGZpbGw9IiMyOTNkNDQiLz48Y2lyY2xlIGN4PSIxODUiIGN5PSIxNDAiIHI9IjE4IiBmaWxsPSIjZTRlNmU2Ii8+PGcgZmlsbD0iI2U0ZTZlNiI+PGNpcmNsZSBjeD0iMTg1IiBjeT0iMTEzIiByPSI1Ii8+PGNpcmNsZSBjeD0iMTYwIiBjeT0iMTQ4IiByPSI1Ii8+PGNpcmNsZSBjeD0iMjEwIiBjeT0iMTQ4IiByPSI1Ii8+PC9nPjwvc3ZnPg==" },
      { id: "TYR-1006", code: "DEMO-CAT-006", name: "Filtro de Aceite Mazda 3 / Mazda 6 / CX-5", brand: "Mazda", priceCOP: 45000, stock: 80, loc: "Pasillo 1 - Estante 1 - Cajón 2", specs: "Ejemplo de catálogo. Referencia y compatibilidad pendientes de confirmación.", img: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzODAgMjcwIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9Im1ldGFsIiB4Mj0iLjkiIHkyPSIxIj48c3RvcCBzdG9wLWNvbG9yPSIjZDVkY2RmIi8+PHN0b3Agb2Zmc2V0PSIuNDUiIHN0b3AtY29sb3I9IiM4OTliYTMiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNjN2QwZDQiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iMzgwIiBoZWlnaHQ9IjI3MCIgZmlsbD0iIzE5MWQyMCIvPjxlbGxpcHNlIGN4PSIxOTAiIGN5PSIyMjUiIHJ4PSIxMDMiIHJ5PSI5IiBmaWxsPSIjMTczMTM5IiBvcGFjaXR5PSIuMDgiLz48ZWxsaXBzZSBjeD0iMTg1IiBjeT0iOTgiIHJ4PSI2MSIgcnk9IjI0IiBmaWxsPSIjZDdkZGRmIi8+PHBhdGggZD0iTTEyNCA5OHYxMDVxNjEgNDIgMTIyIDBWOThxLTYxIDQwLTEyMiAwIiBmaWxsPSJ1cmwoI21ldGFsKSIvPjxlbGxpcHNlIGN4PSIxODUiIGN5PSI5OCIgcng9IjQzIiByeT0iMTYiIGZpbGw9IiMyYTQwNDYiLz48cGF0aCBkPSJNMTI2IDEzMHE2MCAzMCAxMTggMHY0MnEtNjAgMzAtMTE4IDAiIGZpbGw9IiMyOTNkNDQiLz48dGV4dCB4PSIxNTgiIHk9IjE1OCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE1IiBmaWxsPSIjZWVlIiBsZXR0ZXItc3BhY2luZz0iMyI+VFI8L3RleHQ+PC9zdmc+" }
    ];

    let cart = [];
    let salesChartInstance = null;

    window.addEventListener('DOMContentLoaded', () => {
      try { const ids=JSON.parse(localStorage.getItem('toyorenault-cart')||'[]'); if(Array.isArray(ids)) cart=ids.slice(0,100).map(id=>catalogData.find(p=>p.id===id)).filter(Boolean); } catch {}
      updateCartUI(); renderCatalog(catalogData);
      document.getElementById('mainSearchInput').addEventListener('input',filterCatalog);
      document.addEventListener('keydown', e=>{if(e.key==='Escape') ['cartModal','aiBotModal','authPortalSheet'].forEach(id=>document.getElementById(id).classList.add('hidden'));});
    });

    // SISTEMA DE AUTH PORTAL INDEPENDIENTE
    function toggleAuthPortal() {
      const portal = document.getElementById('authPortalSheet');
      portal.classList.toggle('hidden');
    }

    // PESTAÑAS DEL CENTRO TÉCNICO
    function switchTechTab(tab) {
      ['despiece', 'placa', 'vin', 'fluidos', 'km', 'obd2'].forEach(t => {
        const el = document.getElementById(`techTabContent-${t}`);
        if (el) el.classList.add('hidden');
        const btn = document.getElementById(`tabBtn-${t}`);
        if (btn) btn.className = "px-4 py-2 rounded-xl text-xs font-bold bg-zinc-800 text-zinc-400 hover:text-white transition flex items-center gap-1.5";
      });

      const activeEl = document.getElementById(`techTabContent-${tab}`);
      if (activeEl) activeEl.classList.remove('hidden');
      const activeBtn = document.getElementById(`tabBtn-${tab}`);
      if (activeBtn) activeBtn.className = "px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 text-white transition flex items-center gap-1.5";
    }

    function formatPrice(priceCOP) {
      if (currentCurrency === 'USD') return `$${(priceCOP * exchangeRates.USD).toFixed(2)} USD`;
      if (currentCurrency === 'USDT') return `${(priceCOP * exchangeRates.USDT).toFixed(2)} USDT`;
      return `$${priceCOP.toLocaleString('es-CO')} COP`;
    }

    function changeCurrency(curr) {
      currentCurrency = curr;
      filterCatalog();
      updateCartUI();
      calculateShipping();
    }

    function updateKMPlan() {
      const km = document.getElementById('kmSelect').value;
      const grid = document.getElementById('kmPlanResultGrid');

      const plans = {
        "10k": [
          { title: "Cambio Aceite & Filtro", desc: "Sintético + filtro original." },
          { title: "Rotación Llantas", desc: "Balanceo y torque de pernos." },
          { title: "Diagnóstico técnico", desc: "Escaneo de errores gratis." }
        ],
        "50k": [
          { title: "Frenos & Líquido", desc: "DOT 4 y rectificado." },
          { title: "Bujías Iridio", desc: "Calibración optimización." },
          { title: "Cuerpo Aceleración", desc: "Limpieza ultrasónica." }
        ],
        "100k": [
          { title: "Kit Distribución", desc: "Correa, patín y polea." },
          { title: "Bomba Agua", desc: "Reemplazo refrigerante." },
          { title: "Inyección Ultrasónica", desc: "Limpieza en banco." }
        ],
        "150k": [
          { title: "Overhaul Suspensión", desc: "Amortiguadores y bujes." },
          { title: "Aceite Transmisión", desc: "Aceite sintético caja." },
          { title: "Revisión de motor", desc: "Peritaje de motor." }
        ]
      };

      grid.innerHTML = plans[km].map(p => `
        <div class="p-3 bg-zinc-900 rounded-xl border border-zinc-800 space-y-1">
          <strong class="text-white block text-xs">${p.title}</strong>
          <p class="text-zinc-400 text-[10px]">${p.desc}</p>
        </div>
      `).join('');
    }

    function checkPlateColombia() {
      const plate=document.getElementById('plateCheckInput').value.trim().toUpperCase();
      document.getElementById('plateCheckResultBox').textContent=/^[A-Z]{3}[0-9]{3}$/.test(plate) ? `Placa ${plate}: consulta las restricciones vigentes con la autoridad de tránsito. No hay consulta oficial conectada.` : 'Introduce una placa de automóvil de Colombia: tres letras y tres números.';
    }

    function decodeVIN() {
      const vin=document.getElementById('vinCodeInput').value.trim().toUpperCase();
      document.getElementById('vinResultBox').textContent=/^[A-HJ-NPR-Z0-9]{17}$/.test(vin) ? `Formato VIN válido: ${vin}. Identificación y compatibilidad pendientes de consulta en catálogo oficial. No hay un proveedor EPC conectado.` : 'VIN no válido: introduce 17 letras y números, sin I, O ni Q.';
    }

    function diagnoseOBD2() {
      const code = document.getElementById('obd2CodeInput').value.trim().toUpperCase();
      const res = document.getElementById('obd2ResultBox');
      if (!code) return alert('Ingrese un código OBD2.');

      const codes = {
        "P0300": "Fallo de encendido detectado en múltiples cilindros. Revisar bujías/bobinas.",
        "P0420": "Eficiencia del catalizador por debajo del umbral. Revisar sensor de oxígeno.",
        "P0171": "Sistema demasiado pobre (Banco 1). Posible entrada de aire o inyectores sucios.",
        "P0401": "Flujo insuficiente de recirculación de gases de escape (EGR)."
      };

      res.innerHTML = `
        <div class="text-left space-y-1 text-xs">
          <strong class="text-blue-400 block">Diagnóstico Código ${code}:</strong>
          <p class="text-white">${codes[code] || "Falla electrónica registrada en la computadora de a bordo. Solicita diagnóstico en un taller de tu elección."}</p>
        </div>
      `;
    }

    function calculateEngineFluids() { document.getElementById('fluidResultGrid').textContent='La capacidad, viscosidad y referencia del filtro deben confirmarse en el manual del vehículo según motor y año. No hay datos del fabricante verificados.'; }

    function showPartDetail(partName) { document.getElementById('partDetailBox').textContent=`${partName}: esquema ilustrativo. Referencia, torque, compatibilidad y stock pendientes de validación OEM.`; }

    function loadEngineDiagram() { document.getElementById('partDetailBox').textContent='Esquema ilustrativo: sin conexión a EPC del fabricante. Solicita el despiece oficial con el VIN.'; }

    function renderCatalog(items) {
      document.getElementById('partsGrid').innerHTML = !items.length ? '<p class="text-zinc-300 p-4">No encontramos piezas con esa búsqueda. Prueba una marca o referencia.</p>' : items.map(item => `
        <div class="ios-card rounded-2xl overflow-hidden flex flex-col justify-between">
          <div>
            <div class="relative h-36 overflow-hidden bg-zinc-900">
              <img src="${item.img}" alt="Ilustración conceptual para ${item.brand}" loading="lazy" class="w-full h-full object-cover">
              <span class="absolute top-2 left-2 text-[9px] font-bold bg-black/80 text-white px-2 py-0.5 rounded border border-white/10 uppercase">${item.brand}</span>
              <span class="absolute top-2 right-2 text-[9px] font-bold bg-blue-950 text-blue-400 px-2 py-0.5 rounded border border-blue-800"><i class="fa-solid fa-shield-check mr-1"></i>Consultar garantía</span>
            </div>
            <div class="p-3.5">
              <span class="text-[9px] font-mono text-zinc-500 block mb-1">SKU: ${item.code}</span>
              <h4 class="font-bold text-xs text-white leading-snug mb-1">${item.name}</h4>
              <p class="text-zinc-400 text-[10px] leading-relaxed mb-2">${item.specs}</p>
              <span class="text-[9px] text-purple-400 font-semibold block"><i class="fa-solid fa-location-dot mr-1"></i>Ubicación por confirmar</span>
            </div>
          </div>
          <div class="p-3.5 pt-0 flex items-center justify-between border-t border-zinc-800/60 mt-2">
            <div>
              <span class="text-[9px] text-zinc-500 block">Precio de muestra</span>
              <span class="text-sm font-black text-white">${formatPrice(item.priceCOP)}</span>
            </div>
            <button aria-label="Añadir ${item.name} a cotización" onclick="addToCart('${item.id}')" class="w-8 h-8 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-600/30">
              <i class="fa-solid fa-plus text-xs"></i>
            </button>
          </div>
        </div>
      `).join('');
    }

    function filterCatalog() {
      const q = document.getElementById('mainSearchInput').value.toLowerCase();
      const results=catalogData.filter(i => i.name.toLowerCase().includes(q) || i.code.toLowerCase().includes(q) || i.brand.toLowerCase().includes(q)); renderCatalog(results); if(!results.length){const message=document.createElement('p');message.className='catalog-empty';message.textContent='Sin coincidencias en el catálogo de muestra. Consulta las opciones de proveedores o ajusta tu búsqueda.';document.getElementById('partsGrid').append(message);}
    }

    function startVoiceSearch() { alert('Búsqueda por voz pendiente de conexión. Puedes escribir la marca, pieza o referencia en el buscador.'); }

    function triggerCardScanSim() { alert('OCR no conectado. Introduce el VIN manualmente; no se capturan documentos.'); }

    function calculateShipping() {
      const c = document.getElementById('shippingCitySelect').value;
      document.getElementById('shippingCostText').innerText = formatPrice(parseInt(c));
    }

    function toggleCartModal() { document.getElementById('cartModal').classList.toggle('hidden'); }
    function addToCart(id) { const item=catalogData.find(p=>p.id===id); if(item && cart.length<100) { cart.push(item); updateCartUI(); } }

    function updateCartUI() {
      document.getElementById('cartBadge').textContent=cart.length;
      const total=cart.reduce((sum,p)=>sum+p.priceCOP,0);
      document.getElementById('cartItemsContainer').innerHTML=cart.length ? cart.map((p,n)=>`<div class="bg-zinc-900 p-3 rounded-xl text-xs"><p>${p.name}</p><div class="flex justify-between mt-2"><span>${formatPrice(p.priceCOP)}</span><button onclick="removeCartItem(${n})" aria-label="Quitar pieza" class="text-red-400">Quitar</button></div></div>`).join('') : '<p class="text-zinc-400">Tu lista está vacía.</p>';
      document.getElementById('cartTotal').textContent=formatPrice(total);
      document.getElementById('installment3x').textContent=formatPrice(Math.round(total/3));
      try { localStorage.setItem('toyorenault-cart',JSON.stringify(cart.map(p=>p.id))); } catch {} 
    }
    function removeCartItem(index) { cart.splice(index,1); updateCartUI(); }

    function exportCartToWhatsApp() { const vehicle=window.TR_getVehicleContext?.();const message=['Hola TOYORENAULT, necesito consultar estos repuestos:',vehicle?[vehicle.brand,vehicle.model,vehicle.year].filter(Boolean).join(' '):'',...cart.map(p=>p.code+' · '+p.name),'Confirmar compatibilidad, precio y disponibilidad.'].filter(Boolean).join('\n');window.open('https://wa.me/573166926322?text='+encodeURIComponent(message),'_blank','noopener,noreferrer'); }

    function processCheckout() {
      if(!cart.length) return alert('Añade piezas a la solicitud.');
      const vehicle=window.TR_getVehicleContext?.();const text=['SOLICITUD DE COTIZACIÓN — TOYORENAULT',new Date().toLocaleString('es-CO'),vehicle?'VEHÍCULO: '+[vehicle.brand,vehicle.model,vehicle.year,vehicle.plate&&'Placa '+vehicle.plate,vehicle.vin&&'VIN '+vehicle.vin,vehicle.chassis&&'Bastidor '+vehicle.chassis].filter(Boolean).join(' · '):'Vehículo pendiente de identificar','',...cart.map(p=>`${p.code} · ${p.name} · ${formatPrice(p.priceCOP)} (precio de muestra)`),'','No constituye pedido ni pago. Confirmar OEM, compatibilidad, disponibilidad e impuestos.'].join('\n');
      const url=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'})); const a=document.createElement('a'); a.href=url; a.download='solicitud-cotizacion.txt'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
    }

    function toggleAIBot() { document.getElementById('aiBotModal').classList.toggle('hidden'); }
    function sendBotMessage() {
      const input=document.getElementById('botInput'), text=input.value.trim().slice(0,1000); if(!text) return;
      const box=document.getElementById('botChatMessages');
      const append=(message,cls)=>{ const el=document.createElement('div'); el.className=cls+' p-3 rounded-2xl max-w-[85%]'; el.textContent=message; box.appendChild(el); };
      append(text,'bg-red-600/20 ml-auto'); input.value='';
      const matches=catalogData.filter(p=>(p.name+' '+p.code+' '+p.brand).toLowerCase().includes(text.toLowerCase()));
      let reply=matches.length ? matches.map(p=>p.name+' · '+p.code).join('\n')+'\nSon datos de muestra. Solicita confirmación de referencia, precio y disponibilidad.' : 'Puedo ayudarte a buscar en el catálogo de muestra. Escribe una marca o referencia. Para comprobar compatibilidad solicita revisión del VIN al almacén; no tengo acceso a EPC ni a IA externa.';
      if(/pedido|compra|pago/i.test(text)) reply='Añade piezas a tu lista y descarga la solicitud de cotización. Este sitio no registra pedidos ni cobra pagos.';
      append(reply,'bg-zinc-800'); box.scrollTop=box.scrollHeight;
    }

    function triggerExcelImportSim() { alert('La importación de proveedores requiere conectar una base de datos. No se ha cargado ni sincronizado ningún inventario.'); }

  