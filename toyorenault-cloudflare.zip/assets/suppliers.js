// Local portfolio workspace. No supplier credentials or purchase prices are shipped.
(() => {
  const key='toyorenault-suppliers-v1', draftKey='toyorenault-supplier-draft-v1', $=id=>document.getElementById(id);
  let rows=[], requests=[];
  const number=v=>v.trim()==='' ? null : Number(v);
  const safe=r=>r && ['proveedor','referencia','nombre','marca','actualizado'].every(k=>typeof r[k]==='string') && ['stock_propio','stock_proveedor','precio_cop','plazo_dias'].every(k=>r[k]===null || (Number.isFinite(r[k]) && r[k]>=0)) && ['stock_propio','stock_proveedor','plazo_dias'].every(k=>r[k]===null || Number.isInteger(r[k])) && Number.isFinite(Date.parse(r.actualizado)) && Date.parse(r.actualizado)<=Date.now();
  try { const saved=JSON.parse(localStorage.getItem(key)||'[]'); if(Array.isArray(saved)) rows=saved.filter(safe).slice(0,10000); } catch {}
  try { const saved=JSON.parse(localStorage.getItem(draftKey)||'[]'); if(Array.isArray(saved)) requests=saved.filter(r=>safe(r)&&Number.isInteger(r.cantidad)&&r.cantidad>0&&rows.some(p=>p.proveedor===r.proveedor&&p.referencia===r.referencia)).slice(0,10000); } catch {}
  function parseCSV(text) {
    const records=[]; let row=[], field='', quoted=false;
    text=text.replace(/^\uFEFF/,'');
    for(let i=0;i<text.length;i++) {
      const c=text[i];
      if(c==='"') { if(quoted && text[i+1]==='"') {field+='"';i++;} else quoted=!quoted; }
      else if(c===',' && !quoted) { row.push(field); field=''; }
      else if((c==='\n'||c==='\r') && !quoted) { if(c==='\r' && text[i+1]==='\n')i++; row.push(field); if(row.some(v=>v.trim()))records.push(row); row=[];field=''; }
      else field+=c;
    }
    if(quoted) throw Error('El CSV contiene comillas sin cerrar.');
    row.push(field); if(row.some(v=>v.trim()))records.push(row);
    const headers=records.shift()?.map(v=>v.trim().toLowerCase());
    const required=['proveedor','referencia','nombre','marca','stock_propio','stock_proveedor','precio_cop','plazo_dias','actualizado'];
    if(!headers || required.some(k=>!headers.includes(k)) || new Set(headers).size!==headers.length) throw Error('Usa las columnas de la plantilla CSV.');
    if(!records.length || records.length>10000) throw Error('El archivo debe contener entre 1 y 10.000 filas.');
    const seen=new Set();
    return records.map((values,n)=>{
      if(values.length!==headers.length) throw Error(`Fila ${n+2}: número de columnas incorrecto.`);
      const r=Object.fromEntries(headers.map((h,i)=>[h,values[i].trim()]));
      required.slice(4,8).forEach(k=>r[k]=number(r[k]));
      if(!safe(r) || !r.proveedor || !r.referencia || !r.nombre || !r.marca || required.slice(0,4).some(k=>r[k].length>300)) throw Error(`Fila ${n+2}: revisa nombres, cantidades, precios y fecha (no futura).`);
      const id=r.proveedor.toLowerCase()+'|'+r.referencia.toLowerCase();
      if(seen.has(id)) throw Error(`Fila ${n+2}: referencia duplicada para el mismo proveedor.`); seen.add(id);
      return r;
    });
  }
  function download(text,filename) {
    const url=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'})); const a=document.createElement('a'); a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function render() {
    window.dispatchEvent(new Event("supplierPortfolioChanged"));
    try {localStorage.setItem(draftKey,JSON.stringify(requests));}catch{}
    const q=$('supplierSearch').value.trim().toLowerCase(), supplier=$('supplierFilter').value;
    const filtered=rows.filter(r=>(!supplier||r.proveedor===supplier)&&[r.proveedor,r.referencia,r.nombre,r.marca].join(' ').toLowerCase().includes(q));
    $('supplierSummary').textContent=`${new Set(rows.map(r=>r.proveedor)).size} proveedores · ${rows.length} referencias importadas · ${filtered.length} resultados · ${requests.length} líneas en solicitud`;
    const container=$('supplierResults');container.replaceChildren();
    if(!filtered.length) { const p=document.createElement('p');p.textContent=rows.length?'No hay coincidencias.':'Aún no hay proveedores conectados. Importa un CSV para consultar el portafolio en este navegador.';p.className='text-zinc-400 py-4';container.appendChild(p);return; }
    filtered.slice(0,100).forEach(r=>{
      const stale=Date.now()-Date.parse(r.actualizado)>86400000;
      const card=document.createElement('article');card.className='ios-card p-4 rounded-2xl space-y-2';
      const own=r.stock_propio, available=r.stock_proveedor;
      const status=own>0?'Stock propio informado':available>0?'Sobre pedido · confirmar con proveedor':'Disponibilidad por consultar';
      const heading=document.createElement('h3');heading.className='font-bold text-white';heading.textContent=r.nombre;card.appendChild(heading);
      const details=[`${r.marca} · ${r.referencia}`,`Proveedor: ${r.proveedor}`,status,`Stock propio: ${own??'sin dato'} · Proveedor: ${available??'sin dato'}`,`Precio proveedor: ${r.precio_cop===null?'por consultar':'$'+r.precio_cop.toLocaleString('es-CO')+' COP'}`,`Plazo informado: ${r.plazo_dias===null?'por consultar':r.plazo_dias+' días'}`,`Actualizado: ${new Date(r.actualizado).toLocaleString('es-CO')} · ${stale?'Dato antiguo':'Carga reciente'} · Sin conexión en vivo`];
      details.forEach(text=>{const p=document.createElement('p');p.className='text-xs text-zinc-300';p.textContent=text;card.appendChild(p);});
      const button=document.createElement('button');button.className='bg-red-600 px-3 py-2 rounded-xl text-xs';button.textContent='Preparar consulta al proveedor';
      button.addEventListener('click',()=>{const quantity=Number($('supplierQuantity').value);if(!Number.isInteger(quantity)||quantity<1||quantity>9999){$('supplierNotice').textContent='Cantidad válida: 1 a 9.999 unidades.';return;} const prior=requests.find(p=>p.proveedor===r.proveedor&&p.referencia===r.referencia);if(prior) prior.cantidad+=quantity;else requests.push({...r,cantidad:quantity});$('supplierNotice').textContent='Añadido a la solicitud local. No se ha reservado stock ni enviado ningún pedido.';render();});card.appendChild(button);container.appendChild(card);
    });
    if(filtered.length>100){const p=document.createElement('p');p.textContent='Mostrando 100 resultados. Usa la búsqueda para afinar la consulta.';container.appendChild(p);}
  }
  $('supplierFile').addEventListener('change',async e=>{
    const file=e.target.files[0];if(!file)return;
    try {
      if(file.size>5*1024*1024)throw Error('El archivo supera 5 MB.');
      const next=parseCSV(await file.text());
      localStorage.setItem(key,JSON.stringify(next));rows=next;requests=[];
      $('supplierFilter').replaceChildren(new Option('Todos los proveedores',''),...Array.from(new Set(rows.map(r=>r.proveedor))).sort().map(p=>new Option(p,p)));
      $('supplierNotice').textContent='Portafolio cargado en este navegador. La importación reemplazó la anterior; no es una sincronización en vivo.';render();
    } catch(err){$('supplierNotice').textContent=err.message+' Se conserva el portafolio anterior.';}
    e.target.value='';
  });
  $('supplierTemplate').addEventListener('click',()=>download('proveedor,referencia,nombre,marca,stock_propio,stock_proveedor,precio_cop,plazo_dias,actualizado\n','plantilla-proveedores.csv'));
  $('supplierExport').addEventListener('click',()=>{
    if(!requests.length){$('supplierNotice').textContent='Añade referencias antes de descargar la solicitud.';return;}
    download(['SOLICITUD A PROVEEDORES — PENDIENTE DE CONFIRMACIÓN',new Date().toLocaleString('es-CO'),...requests.map(r=>`${r.proveedor} | ${r.referencia} | ${r.nombre} | Cantidad: ${r.cantidad} | Dato: ${r.actualizado}`),'Confirmar disponibilidad, precio, plazo, compatibilidad OEM y condiciones. No constituye orden de compra.'].join('\n'),'solicitud-proveedores.txt');
  });
  $('supplierClear').addEventListener('click',()=>{rows=[];requests=[];try{localStorage.removeItem(key);}catch{}$('supplierFilter').replaceChildren(new Option('Todos los proveedores',''));$('supplierNotice').textContent='Portafolio local eliminado. Puedes recuperarlo importando tu CSV.';render();});
  $('supplierSearch').addEventListener('input',render);$('supplierFilter').addEventListener('change',render);
  $('supplierFilter').replaceChildren(new Option('Todos los proveedores',''),...Array.from(new Set(rows.map(r=>r.proveedor))).sort().map(p=>new Option(p,p)));render();
})();
