(()=>{'use strict';const $=id=>document.getElementById(id);let previewURL;
$('vehicleCard').onchange=e=>{const f=e.target.files[0];if(previewURL)URL.revokeObjectURL(previewURL);$('cardPreview').hidden=true;if(!f)return;if(!['image/jpeg','image/png','image/webp'].includes(f.type)||f.size>10*1024*1024){$('vehicleStatus').textContent='Selecciona una imagen JPG, PNG o WebP de hasta 10 MB.';return}previewURL=URL.createObjectURL(f);$('cardPreview').src=previewURL;$('cardPreview').hidden=false};

})();
